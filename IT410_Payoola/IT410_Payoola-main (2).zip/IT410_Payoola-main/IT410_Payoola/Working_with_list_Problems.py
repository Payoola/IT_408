favorite_marvel_movies = ["The Incredible Hulk", "SpiderMan 3", "Avengers: Endgame", "Ghost Rider"]

print(favorite_marvel_movies)

favorite_marvel_movies.append("Iron Man")

favorite_marvel_movies.remove("SpiderMan 3")

print(favorite_marvel_movies)

favorite_marvel_movies[1] = "Avengers: Civil War"

print(favorite_marvel_movies)

favorite_marvel_movies.sort()

print(favorite_marvel_movies)

favorite_marvel_movies.reverse()

print(favorite_marvel_movies)