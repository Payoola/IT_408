variable1 = 24
variable2 = "string value of some sort"
variable3 = 3.14159

if type(variable3) is int:
    print("the variable is an interger.")
elif type(variable3) is str:
    print("the variable is a string.")
elif type(variable3) is float:
    print("the variable is a floating point type")
else:
    print("the variable is something else.")


