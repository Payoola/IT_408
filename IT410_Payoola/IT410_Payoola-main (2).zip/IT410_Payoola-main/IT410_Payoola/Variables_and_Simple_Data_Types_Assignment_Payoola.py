#Problem 1-4
first_name = "Prize"        
last_name = " Ayoola"           

print(first_name.lower() + last_name.upper())       

print("Hello,\nmy name is\n", first_name.lower() + last_name.upper())       

#Problem 5
print("\"Start by doing what's necessary; then do what's possible; and suddenly you are doing the impossible - Francis of Assisi\"")

#Problem 6-8
first_decimanl = 5.5

second_decimal = 2.4

addition_results = (first_decimanl + second_decimal)
subtraction_results = (first_decimanl - second_decimal)
multiplication_results = (first_decimanl * second_decimal)
division_results = (first_decimanl / second_decimal)

print(f"{first_decimanl} plus {second_decimal} equals {addition_results}")

print(f"{first_decimanl} miuns {second_decimal} equals {subtraction_results}")

print(f"{first_decimanl} times {second_decimal} equals {multiplication_results}")

print(f"{first_decimanl} divided {second_decimal} equals {division_results}")

#Problem
current_month = "November"

day_of_month = 14

print(f"\t\tToday is day {day_of_month} of the month of {current_month}.")
