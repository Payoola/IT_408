#working with strings example code
string_var = 'hell\'o'

string_name = " Prize \"Ayoola\""

string_name = string_name.upper()

print(string_var + string_name)

print(string_name)

print(string_var + "\n\t" + string_name)