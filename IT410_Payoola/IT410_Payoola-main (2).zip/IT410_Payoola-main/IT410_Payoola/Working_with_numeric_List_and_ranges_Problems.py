numbers = list(range(1,11,2))

for number in numbers:
    print(945/number)

print(min(numbers))
print(max(numbers))
print(sum(numbers))