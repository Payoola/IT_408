#Problem 2-1
favorite_resturant = "Olive Garden"

print(favorite_resturant)

favorite_dish = "Aflredo Pasta"

print(favorite_dish)

#Problem 2-2
last_store = "Kroger"

purchased_item = "Potatoes"

print("The last store I went to was " + last_store + ", I purchased " + purchased_item + ".")

#Problem 2-3
favorite_car = "Dodge Challenger"

print(favorite_car.upper())
print(favorite_car.lower())
print(favorite_car.title())

#Problem 2-4
favorite_quote = "All glitters is not gold"
formatted_quote = "\t\n" + favorite_quote + "\t\n"

print(formatted_quote)

lstrip_quote = formatted_quote.lstrip()

print(lstrip_quote)

strip_quote = formatted_quote.strip()

print(strip_quote)

#Problem 2-5
addition_result = 5 + 5

print("The result of my math problem is " + str(addition_result))
