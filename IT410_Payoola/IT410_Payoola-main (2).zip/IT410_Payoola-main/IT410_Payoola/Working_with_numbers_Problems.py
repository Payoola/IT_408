numberThree = 3

numberFour = 4

math_results = numberThree * numberFour + numberThree

print(math_results)